// API key
const API_KEY = "pk.eyJ1IjoiaGJvc3RhbmNoaSIsImEiOiJjazUyeXdqNXgwMzM2M21udHBydGJ4OHllIn0.VJBG1JKQpfECTt3vM5Qgxw"